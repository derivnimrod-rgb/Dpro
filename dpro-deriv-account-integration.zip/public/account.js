const $ = (id) => document.getElementById(id);
const loginCard = $("loginCard");
const dashboard = $("dashboard");
const accountSelect = $("accountSelect");
const statusEl = $("status");

let accounts = [];

function showError(message) {
  statusEl.textContent = message;
  statusEl.className = "status error";
}

function setStatus(message) {
  statusEl.textContent = message;
  statusEl.className = "status";
}

async function api(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: { "Accept": "application/json", ...(options.headers || {}) }
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

async function loadAccount(accountId) {
  setStatus("Loading account information…");
  $("balance").textContent = "—";
  $("accountId").textContent = "—";
  $("currency").textContent = "—";
  $("positionsCount").textContent = "—";
  $("positions").textContent = "Loading…";

  try {
    const data = await api(`/api/account/${encodeURIComponent(accountId)}`);
    const account = data.account || {};
    const portfolio = data.portfolio || {};
    const positions = portfolio.contracts || portfolio.positions || [];

    $("balance").textContent =
      account.balance == null ? "—" :
      `${Number(account.balance).toLocaleString(undefined, {maximumFractionDigits: 2})} ${account.currency || ""}`;

    $("accountId").textContent = account.id || accountId;
    $("currency").textContent = account.currency || "—";
    $("positionsCount").textContent = positions.length;

    if (!positions.length) {
      $("positions").innerHTML = '<div class="muted">No open positions.</div>';
    } else {
      $("positions").innerHTML = positions.map((p) => {
        const symbol = p.underlying_symbol || p.symbol || "—";
        const type = p.contract_type || p.contract_type_display || "—";
        const buyPrice = p.buy_price ?? p.buy_price_display ?? "—";
        const current = p.bid_price ?? p.current_spot ?? p.current_value ?? "—";
        return `<div class="position">
          <strong>${escapeHtml(symbol)}</strong>
          <div class="muted">${escapeHtml(type)}</div>
          <div>Buy: ${escapeHtml(buyPrice)} &nbsp; Current: ${escapeHtml(current)}</div>
        </div>`;
      }).join("");
    }

    setStatus(`Updated ${new Date().toLocaleTimeString()}.`);
  } catch (err) {
    showError(err.message);
  }
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function init() {
  try {
    const session = await api("/api/session");

    if (!session.connected) {
      loginCard.hidden = false;
      dashboard.hidden = true;
      return;
    }

    loginCard.hidden = true;
    dashboard.hidden = false;

    const result = await api("/api/accounts");
    accounts = result.accounts || [];

    if (!accounts.length) {
      throw new Error("No Deriv Options trading accounts were returned.");
    }

    accountSelect.innerHTML = accounts.map((a) => {
      const label = `${a.id}${a.currency ? ` — ${a.currency}` : ""}${a.isDemo ? " — Demo" : ""}`;
      return `<option value="${escapeHtml(a.id)}">${escapeHtml(label)}</option>`;
    }).join("");

    await loadAccount(accountSelect.value);
  } catch (err) {
    showError(err.message);
  }
}

accountSelect.addEventListener("change", () => loadAccount(accountSelect.value));
$("refresh").addEventListener("click", () => loadAccount(accountSelect.value));

init();
