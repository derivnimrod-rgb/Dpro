# Dpro + Deriv Account Information Integration

This package adds a **read-only** Deriv account dashboard to Dpro.

It uses Deriv's current OAuth 2.0 + PKCE flow, the Options account list endpoint, the account OTP endpoint, and an authenticated WebSocket for `balance` and `portfolio`.

## What it does

- Connects the user through Deriv OAuth.
- Lists the user's Options trading accounts.
- Gets the selected account's balance and currency.
- Gets open positions.
- Does NOT implement buy, sell, deposits, withdrawals, or account-management actions.

## Important architecture

Your existing Dpro site is on GitHub Pages. GitHub Pages can host the frontend, but it cannot safely run the OAuth token exchange or a Node.js WebSocket backend.

Use this project as the backend, deployed on a Node-compatible host such as Render, Railway, Fly.io, or your own server. Your GitHub Pages Dpro site can then call the backend.

## 1. Register the OAuth app with Deriv

In Deriv's developer area, create/register an OAuth 2.0 application.

Use an HTTPS redirect URI such as:

https://YOUR-BACKEND-DOMAIN/auth/callback

The redirect URI must exactly match what you configure in `.env`.

Request the `trade` scope. The current Deriv documentation lists `trade` for getting Options accounts and generating the authenticated WebSocket URL.

## 2. Configure the backend

Copy:

.env.example -> .env

Set:

DERIV_CLIENT_ID=your_client_id
DERIV_REDIRECT_URI=https://YOUR-BACKEND-DOMAIN/auth/callback
SESSION_SECRET=a-long-random-secret
APP_ORIGIN=https://YOUR-BACKEND-DOMAIN
NODE_ENV=production

Do NOT put an OAuth access token in your GitHub Pages JavaScript.

## 3. Install and run

```bash
npm install
npm start
```

Open:

http://localhost:3000/account.html

## 4. GitHub Pages Dpro integration

Upload `github-pages/account-widget.js` into your Dpro repository.

Then add this near the account/mentor section of your existing `index.html`:

```html
<script>
  window.DPRO_API_BASE = "https://YOUR-BACKEND-DOMAIN";
</script>
<script src="./account-widget.js"></script>
```

Because the frontend is on a different origin, the backend must also be configured for cross-origin requests if you use the widget. For the simplest deployment, serve `account.html` from the backend itself. If you want the widget embedded directly in GitHub Pages, add a CORS middleware to the backend that allows only your exact GitHub Pages origin.

## 5. Recommended first test

Test with a Deriv demo account first.

Flow:

Dpro -> Connect Deriv -> Deriv login/consent -> callback -> account list -> balance -> open positions.

## Security

- Never ask users for their Deriv password.
- Never paste a user's access token into GitHub Pages.
- Keep OAuth token exchange on the backend.
- Validate the OAuth `state`.
- Use PKCE.
- Only allow an account ID returned by the authenticated user's account list.
- This first version contains no trading endpoints.

## Current Deriv API references

- OAuth 2.0 + PKCE
- GET /trading/v1/options/accounts
- POST /trading/v1/options/accounts/{accountId}/otp
- Authenticated WebSocket `balance`
- Authenticated WebSocket `portfolio`

The OTP is short-lived and single-use, so the backend opens the WebSocket immediately after obtaining it.
