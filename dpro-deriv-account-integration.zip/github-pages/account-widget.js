/*
  Add this script to your existing Dpro GitHub Pages site.

  Before loading this file, define:
    window.DPRO_API_BASE = "https://YOUR-BACKEND-DOMAIN";

  Example:
    <script>
      window.DPRO_API_BASE = "https://dpro-deriv-api.onrender.com";
    </script>
    <script src="https://YOURUSERNAME.github.io/dpro/account-widget.js"></script>

  This widget is intentionally read-only: it only displays account information.
*/
(() => {
  const API = (window.DPRO_API_BASE || "").replace(/\/$/, "");
  if (!API) return;

  const root = document.createElement("section");
  root.id = "dpro-deriv-account";
  root.innerHTML = `
    <div style="background:#111;color:#fff;border:1px solid #292929;border-radius:16px;padding:18px;font-family:Arial,sans-serif;max-width:760px;margin:20px auto">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px">
        <div>
          <div style="color:#e31b23;font-weight:900;font-size:22px">DPRO</div>
          <h2 style="margin:4px 0">Deriv Account</h2>
        </div>
        <a id="dpro-connect" href="${API}/auth/deriv" style="background:#e31b23;color:#fff;padding:10px 14px;border-radius:9px;text-decoration:none;font-weight:700">Connect Deriv</a>
      </div>
      <div id="dpro-account-body" style="margin-top:14px;color:#aaa">Checking connection…</div>
    </div>`;
  document.currentScript?.parentNode?.insertBefore(root, document.currentScript);

  const body = root.querySelector("#dpro-account-body");
  const connect = root.querySelector("#dpro-connect");

  async function api(path) {
    const r = await fetch(API + path, { credentials: "include" });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || "Request failed");
    return d;
  }

  async function load() {
    try {
      const session = await api("/api/session");
      if (!session.connected) {
        body.textContent = "Connect your Deriv account to view balance and open positions.";
        return;
      }

      connect.textContent = "Disconnect";
      connect.href = API + "/auth/logout";

      const a = await api("/api/accounts");
      if (!a.accounts?.length) {
        body.textContent = "No Options trading account was returned.";
        return;
      }

      const account = a.accounts[0];
      const data = await api("/api/account/" + encodeURIComponent(account.id));
      const positions = data.portfolio?.contracts || data.portfolio?.positions || [];

      body.innerHTML = `
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px">
          <div><small>Balance</small><div style="font-size:22px;color:#fff">${Number(data.account.balance).toLocaleString(undefined,{maximumFractionDigits:2})} ${data.account.currency || ""}</div></div>
          <div><small>Account</small><div style="font-size:18px;color:#fff">${escapeHtml(data.account.id)}</div></div>
          <div><small>Open positions</small><div style="font-size:22px;color:#fff">${positions.length}</div></div>
        </div>`;
    } catch (e) {
      body.textContent = e.message;
    }
  }

  function escapeHtml(v) {
    return String(v).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
  }

  load();
})();
