import "dotenv/config";
import express from "express";
import session from "express-session";
import crypto from "crypto";
import path from "path";
import { fileURLToPath } from "url";
import WebSocket from "ws";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();

const PORT = Number(process.env.PORT || 3000);
const CLIENT_ID = process.env.DERIV_CLIENT_ID;
const REDIRECT_URI = process.env.DERIV_REDIRECT_URI;
const APP_ORIGIN = process.env.APP_ORIGIN || `http://localhost:${PORT}`;
const SESSION_SECRET = process.env.SESSION_SECRET;

if (!CLIENT_ID || !REDIRECT_URI || !SESSION_SECRET) {
  console.error("Missing DERIV_CLIENT_ID, DERIV_REDIRECT_URI or SESSION_SECRET.");
  process.exit(1);
}

app.set("trust proxy", 1);
app.use(express.json({ limit: "50kb" }));

app.use(
  session({
    name: "dpro.sid",
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 1000 * 60 * 60
    }
  })
);

app.use(express.static(path.join(__dirname, "../public")));

const API_BASE = "https://api.derivws.com";
const AUTH_BASE = "https://auth.deriv.com";

function base64url(buffer) {
  return buffer
    .toString("base64")
    .replaceAll("+", "-")
    .replaceAll("/", "_")
    .replaceAll("=", "");
}

function randomString(bytes = 32) {
  return base64url(crypto.randomBytes(bytes));
}

function sha256Base64url(value) {
  return base64url(crypto.createHash("sha256").update(value).digest());
}

function requireAuth(req, res, next) {
  if (!req.session.accessToken) {
    return res.status(401).json({ error: "Not connected to Deriv." });
  }
  next();
}

async function derivFetch(url, token) {
  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    }
  });

  const body = await response.json().catch(() => ({}));

  if (!response.ok) {
    const message =
      body?.errors?.[0]?.message ||
      body?.error_description ||
      `Deriv API returned HTTP ${response.status}`;
    const err = new Error(message);
    err.status = response.status;
    throw err;
  }

  return body;
}

function normalizeAccounts(result) {
  // The API's account list is kept flexible here so minor response-shape
  // changes do not break the dashboard.
  const candidates =
    result?.data?.accounts ??
    result?.data ??
    result?.accounts ??
    [];

  const list = Array.isArray(candidates)
    ? candidates
    : Object.values(candidates || {});

  return list
    .map((a) => ({
      id: a?.account_id ?? a?.accountId ?? a?.loginid ?? a?.login_id,
      currency: a?.currency,
      accountType: a?.account_type ?? a?.type,
      isDemo:
        a?.is_demo ??
        a?.demo_account ??
        (String(a?.account_id ?? a?.loginid ?? "").startsWith("VRT")),
      raw: a
    }))
    .filter((a) => a.id);
}

async function getAccounts(token) {
  const result = await derivFetch(
    `${API_BASE}/trading/v1/options/accounts`,
    token
  );
  return normalizeAccounts(result);
}

async function getOtpUrl(token, accountId) {
  const response = await fetch(
    `${API_BASE}/trading/v1/options/accounts/${encodeURIComponent(accountId)}/otp`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`
      }
    }
  );

  const body = await response.json().catch(() => ({}));

  if (!response.ok || !body?.data?.url) {
    const message =
      body?.errors?.[0]?.message ||
      `Could not create Deriv WebSocket session (HTTP ${response.status})`;
    const err = new Error(message);
    err.status = response.status;
    throw err;
  }

  return body.data.url;
}

function websocketRequest(wsUrl, request, expectedMsgType, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let finished = false;

    const finish = (fn, value) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      try { ws.close(); } catch {}
      fn(value);
    };

    const timer = setTimeout(() => {
      finish(reject, new Error(`Timed out waiting for ${expectedMsgType}.`));
    }, timeoutMs);

    ws.on("open", () => {
      ws.send(JSON.stringify(request));
    });

    ws.on("message", (raw) => {
      let message;
      try {
        message = JSON.parse(raw.toString());
      } catch {
        return;
      }

      if (message.error) {
        finish(reject, new Error(message.error.message || "Deriv WebSocket error."));
        return;
      }

      if (message.msg_type === expectedMsgType) {
        finish(resolve, message);
      }
    });

    ws.on("error", (err) => {
      finish(reject, err);
    });

    ws.on("close", () => {
      if (!finished) {
        finish(reject, new Error("Deriv WebSocket closed before a response arrived."));
      }
    });
  });
}

app.get("/auth/deriv", (req, res) => {
  const state = randomString(24);
  const verifier = randomString(48);
  const challenge = sha256Base64url(verifier);

  req.session.oauthState = state;
  req.session.codeVerifier = verifier;

  const params = new URLSearchParams({
    response_type: "code",
    client_id: CLIENT_ID,
    redirect_uri: REDIRECT_URI,
    scope: "trade",
    state,
    code_challenge: challenge,
    code_challenge_method: "S256"
  });

  res.redirect(`${AUTH_BASE}/oauth2/auth?${params.toString()}`);
});

app.get("/auth/callback", async (req, res) => {
  try {
    const { code, state, error, error_description } = req.query;

    if (error) {
      return res.status(400).send(
        `<h2>Deriv login was not completed</h2><p>${escapeHtml(
          error_description || error
        )}</p><p><a href="/">Back to Dpro</a></p>`
      );
    }

    if (!code || !state || state !== req.session.oauthState) {
      return res.status(400).send("Invalid OAuth state or authorization code.");
    }

    const verifier = req.session.codeVerifier;
    delete req.session.oauthState;
    delete req.session.codeVerifier;

    const tokenResponse = await fetch(`${AUTH_BASE}/oauth2/token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "authorization_code",
        client_id: CLIENT_ID,
        code: String(code),
        redirect_uri: REDIRECT_URI,
        code_verifier: verifier
      })
    });

    const tokenData = await tokenResponse.json();

    if (!tokenResponse.ok || !tokenData.access_token) {
      throw new Error(
        tokenData?.error_description || "Deriv token exchange failed."
      );
    }

    req.session.accessToken = tokenData.access_token;
    req.session.expiresAt = Date.now() + Number(tokenData.expires_in || 3600) * 1000;

    res.redirect("/account.html");
  } catch (err) {
    console.error("OAuth callback error:", err.message);
    res.status(500).send(
      `<h2>Could not connect to Deriv</h2><p>${escapeHtml(
        err.message
      )}</p><p><a href="/">Back to Dpro</a></p>`
    );
  }
});

app.get("/auth/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/"));
});

app.get("/api/session", (req, res) => {
  res.json({
    connected: Boolean(req.session.accessToken),
    expiresAt: req.session.expiresAt || null
  });
});

app.get("/api/accounts", requireAuth, async (req, res) => {
  try {
    const accounts = await getAccounts(req.session.accessToken);
    res.json({
      accounts: accounts.map(({ raw, ...safe }) => safe)
    });
  } catch (err) {
    console.error("Accounts error:", err.message);
    res.status(err.status === 401 ? 401 : 502).json({ error: err.message });
  }
});

app.get("/api/account/:accountId", requireAuth, async (req, res) => {
  try {
    const accountId = req.params.accountId;

    if (!/^[A-Za-z0-9_-]+$/.test(accountId)) {
      return res.status(400).json({ error: "Invalid account ID." });
    }

    const accounts = await getAccounts(req.session.accessToken);
    const account = accounts.find((a) => a.id === accountId);

    if (!account) {
      return res.status(403).json({ error: "That account is not available to this Deriv session." });
    }

    const wsUrl = await getOtpUrl(req.session.accessToken, accountId);

    const [balanceMessage, portfolioMessage] = await Promise.all([
      websocketRequest(
        wsUrl,
        { balance: 1, req_id: 1 },
        "balance"
      ),
      websocketRequest(
        wsUrl,
        { portfolio: 1, req_id: 2 },
        "portfolio"
      )
    ]);

    res.json({
      account: {
        id: balanceMessage?.balance?.loginid || account.id,
        balance: balanceMessage?.balance?.balance ?? null,
        currency: balanceMessage?.balance?.currency ?? account.currency ?? null
      },
      portfolio: portfolioMessage?.portfolio ?? null
    });
  } catch (err) {
    console.error("Account data error:", err.message);
    res.status(err.status === 401 ? 401 : 502).json({ error: err.message });
  }
});

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "Dpro Deriv Account Integration" });
});

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

app.listen(PORT, () => {
  console.log(`Dpro Deriv integration running on ${APP_ORIGIN}`);
});
